package com.smarthabittracker;

import com.smarthabittracker.ui.HabitTrackerUI;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(HabitTrackerUI.class, args);
    }
}